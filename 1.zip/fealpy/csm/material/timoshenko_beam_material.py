from typing import Optional, Tuple
from builtins import float, str

from fealpy.typing import TensorLike
from fealpy.backend import backend_manager as bm
from fealpy.material.elastic_material import LinearElasticMaterial

from ..model.beam.timobeam_axle_data_3d import TimobeamAxleData3D


class TimoshenkoBeamMaterial(LinearElasticMaterial):
    """Material properties for 3D Timoshenko beams.

    Parameters:
        name (str): The name of the material.
        model (object): The model containing the beam's geometric and material properties.
        E (float): The elastic modulus of the material.
        mu (float): The shear modulus of the material.
    """
    
    def __init__(self, 
                model,
                name: str, 
                elastic_modulus: Optional[float] = None,
                poisson_ratio: Optional[float] = None,
                shear_modulus: Optional[float] = None,
                shear_factor: Optional[float] = None) -> None:
        super().__init__(name=name, 
                        elastic_modulus= elastic_modulus, 
                        poisson_ratio=poisson_ratio,
                        shear_modulus=shear_modulus)

        self.E = self.get_property('elastic_modulus')
        self.nu = self.get_property('poisson_ratio')
        self.mu = self.get_property('shear_modulus')
        self.kappa = shear_factor

        model = TimobeamAxleData3D()

        self.Ax = model.beam_Ax  # 截面面积
        self.Ay = model.beam_Ay  
        self.Az = model.beam_Az  
        self.Iy = model.beam_Iy  # 绕 y 轴惯性矩
        self.Iz = model.beam_Iz  # 绕 z 轴惯性矩
        self.J = model.beam_Ix  # 极惯性矩
        
        
    def __str__(self) -> str:
        s = f"{self.__class__.__name__}(\n"
        s += "  === Material Parameters ===\n"
        s += f"  Name              : {self.get_property('name')}\n"
        s += f"  [Beam]  E           : {self.E}\n"
        s += f"  [Beam]  nu          : {self.nu}\n"
        s += f"  [Beam]  mu          : {self.mu}\n"
        s += ")"
        return s

    def linear_basis(self, x: float, l: float) -> TensorLike:
        """Linear shape functions for a 3D Timoshenko beam element.

        Parameters:
            x (float): Local coordinate along the beam axis.
            l (float): Length of the beam element.

        Returns:
            b (TensorLike): Linear shape functions evaluated at xi.
        """
        xi = x / l  
        t = 1.0 / l
        
        b = bm.zeros((2, 2), dtype=bm.float64)
        
        b[0, 0] = 1 - xi
        b[0, 1] = xi
        b[1, 0] = -t
        b[1, 1] = t
        return b
    
    def hermite_basis(self, x: float, l: float) -> TensorLike:
        """Hermite shape functions for a 3D Timoshenko beam element.

        Parameters:
            x (float): Local coordinate along the beam axis.
            l (float): Length of the beam element.

        Returns:
            b (TensorLike): Hermite shape functions evaluated at xi.
        """
        t0 = 1.0 / l
        t1 = x / l
        t2 = t1 **2
        t3 = t1 **3
        
        h = bm.zeros((3, 4), dtype=bm.float64)
        
        h[0, 0] = 1- 3*t2 + 2*t3
        h[0, 1] = x - 2*x*t1 + x*t2
        h[0, 2] = 3*t2 - 2*t3
        h[0, 3] = -x*t1 +x*t2
        
        # 一阶导数
        h[1, 0] = 6*t0 * (t2 - t1)
        h[1, 1] = 1 - 4*t1 + 3*t2
        h[1, 2] = 6*t0 * (t1 - t2)
        h[1, 3] = 3*t2 - 2*t1

        # 二阶导数
        h[2, 0] = t0**2 * (12*t1 - 6)
        h[2, 1] = t0 * (6*t1 - 4)
        h[2, 2] = t0**2 * (6 - 12*t1)
        h[2, 3] = t0 * (6*t1 - 2)
        return h

    def strain_displacement_matrix(self, x: float, l: float, plane='xy') -> float:
        """Construct the Hermite shape function blocks for bending and rotation.

        Parameters:
            l (float): Length of the beam element.
            plane (str, optional): Plane of interest ('xy', 'zx').

        Returns:
            N (ndarray): Displacement interpolation matrix.shape(6, 12) 
            Nt (ndarray) :Rotation interpolation matrix (derivative form).
        """
        if plane == 'xy':
            Lambda = self.E * self.Iz / (self.kappa * self.mu * self.Ax)
        elif plane == 'zx':
            Lambda = self.E * self.Iy / (self.kappa * self.mu * self.Ax)
        else:
            raise ValueError("plane must be 'yz' or 'xz'")

        phi = 12 * Lambda / l**2
        psi = 1 / (1 + phi)

        # === 轴向 (u) 和 扭转 (θx) ===
        L = self.linear_basis(x, l)
        H = self.hermite_basis(x, l) 
       
        # === 弯曲 (v, w) 和 旋转 (θy, θz) ===
        N0 = psi * (H[0, 0] + phi*L[0, 0])
        N1 = psi * (H[0, 1] + phi*(L[0, 1]-L[0, 1]**2)/2)
        N2 = psi * (H[0, 2] + phi*L[0, 1])
        N3 = psi * (H[0, 3] + phi*(-L[0, 1]+L[0, 1]**2)/2)

        Nt0 =  psi * H[1, 0]
        Nt1 = psi * (H[1, 1] + phi*L[0, 0])
        Nt2 = -psi * H[1, 2]
        Nt3 = psi * (H[1, 3] + phi*L[0, 1])
        
        N = bm.zeros((6, 12), dtype=bm.float64)
        Nt = bm.zeros((6, 12), dtype=bm.float64)
        
        # ---- 组装轴向和扭转部分 ----
        N[0, [0, 6]] = [L[0, 0], L[1, 0]]
        N[3, [3, 9]] = [L[0, 1], L[1, 1]]
        
        # TODO 需要修改
        # ---- 根据平面类型组装矩阵 ---- 
        if plane == 'xy':  # v, θz 平面
            # 对应节点自由度顺序 [u0, v0, w0, θx0, θy0, θz0, u1, v1, w1, θx1, θy1, θz1]
            N[1, [1, 5, 7, 11]] = [N0, N1, N2, N3]   # v
            N[5, [1, 5, 7, 11]] = [Nt0, Nt1, Nt2, Nt3]  # θz
        elif plane == 'zx':  # w, θy 平面
            N[2, [2, 4, 8, 10]] = [N0, N1, N2, N3]   # w
            N[4, [2, 4, 8, 10]] = [Nt0, Nt1, Nt2, Nt3]  # θy

        return N, Nt

    def strain_matrix(self, x: float, y: float,  z: float, l: float) -> TensorLike:
        """ Compute the strain-displacement matrix B for 3D Timoshenko beam element.

        Parameters:
            x (float): Local coordinate in the beam cross-section along the x-axis.
            y (float): Local coordinate in the beam cross-section along the y-axis.
            z (float): Local coordinate in the beam cross-section along the z-axis.
            l (float): Length of the beam element.

        Returns:
            B (TensorLike): Strain-displacement matrix, shape (3, 12).
        """
        L = self.linear_basis(x, l)
        
        B = bm.zeros((3, 12), dtype=bm.float64)

        B[0, 0] = L[0, 0]
        B[0, 4] = z * L[0, 1]
        B[0, 5] = -y * L[0, 1]
        B[1, 1] = L[0, 1]
        B[1,5] = -L[0, 0]
        B[2, 2]  = L[0, 1]
        B[2, 4] = L[0, 0]
        
        B[0, 6] = L[1, 0]
        B[0, 10] = z * L[1, 1]
        B[0, 11] = -y * L[1, 1]
        B[1, 7] = L[1, 1]
        B[1, 11] = -L[1, 0]
        B[2, 8] = L[1, 1]
        B[2, 10] = L[1, 0]    

        return B 
    
    def stress_matrix(self) -> TensorLike:
        """Construct the stress-strain matrix D for a 3D Timoshenko beam element.
        This matrix defines the linear elastic relationship between stress and strain:
                    σ = D * ε
        where:
            σ = [ σ_x, τ_xy, τ_xz ]^T
            
        Parameters:
            kappa(float): Shear correction factor.Typical values:
                Solid rectangular section: κ ≈ 5/6,
                Circular section: κ ≈ 9/10.
                    
        Returns:
            D(TensorLike): Stress-strain matrix, shape (3, 3).
                    [ [E,     0,        0     ],
                    [0,  G/κ,        0     ],
                    [0,     0,     G/κ   ] ]
        """
        E = self.E
        mu = self.mu
        kappa = self.kappa
        
        D = bm.array([[E, 0, 0],
                      [0, mu*kappa, 0],
                      [0, 0, mu*kappa]], dtype=bm.float64)

        return D
    
    def calculate_strain_and_stress(self,
                    uh: TensorLike,
                    x: float,
                    y: float,
                    z: float,
                    l: float) -> Tuple[TensorLike, TensorLike]:
        """Calculate the strain and stress.
                    ε = B * u_e
                    σ = D * ε
                    
        Parameters:
            uh (TensorLike): Nodal displacement vector.
            x (float): Local coordinate in the beam cross-section along the x-axis.
            y (float): Local coordinate in the beam cross-section along the y-axis.
            z (float): Local coordinate in the beam cross-section along the z-axis.
            l (float): Length of the beam element.
            
        Returns:
            Tuple[TensorLike, TensorLike]: Strain and stress vectors.
        """
        L = self.linear_basis(x, l)
        H = self.hermite_basis(x, l) 
        B = self.strain_matrix(x, y, z, l)
        
        strain = B @ uh
        stress = self.stress_matrix() @ strain
        return strain, stress