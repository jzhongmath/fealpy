
import re
from typing import List, Tuple, Dict, Type, Optional, Any
from ..backend import bm
from ..typing import TensorLike


ABAQUS_TYPE_DOF_MAP = {
    'ENCASTRE': [1, 2, 3, 4, 5, 6],
    'PINNED': [1, 2, 3],
    'XSYMM': [1, 5, 6],
    'YSYMM': [2, 4, 6],
    'ZSYMM': [3, 4, 5],
    'XASYMM': [2, 3, 4],
    'YASYMM': [1, 3, 5],
    'ZASYMM': [1, 2, 6],
    # 其它可扩展...
}

class Section:
    """
    Abstract base class for all parsed ABAQUS *.inp file sections.

    Each subclass represents a different section keyword and is responsible for parsing
    corresponding lines and attaching data to the mesh representation.

    Parameters:
        options (Dict[str, str]): Parsed keyword arguments from the section header.

    Attributes:
        options (Dict[str, str]): Stores parsed options for the section.
        keyword (str): Section keyword (e.g., 'NODE', 'ELEMENT'). Must be defined by subclasses.

    Methods:
        match_keyword(keyword: str) -> bool:
            Checks whether the input keyword matches this section's keyword.

        parse_line(line: str) -> None:
            Parses a line within this section. Must be implemented by subclasses.

        attach(meshdata: Dict[str, Any]) -> None:
            Attaches parsed data to the meshdata dictionary (optional override).

        finalize() -> None:
            Finalizes section data (e.g., converts lists to arrays, builds indices).
    """
    keyword: str = ''

    def __init__(self, options: Dict[str, str]):
        self.options = options

    @classmethod
    def match_keyword(cls, keyword: str) -> bool:
        return cls.keyword.upper() == keyword.upper()

    def parse_line(self, line: str) -> None:
        raise NotImplementedError(f"parse_line must be implemented by {self.__class__.__name__}")

    def attach(self, meshdata: Dict[str, Any]):
        pass

    def finalize(self) -> None:
        """
        Optional: convert stored lists to bm.array
        """
        pass


class NodeSection(Section):
    """
    Parses the *NODE section from an ABAQUS .inp file.

    This section defines the global node ID and coordinates for each mesh node.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header.

    Attributes:
        _id (List[int]): Node IDs.
        _node (List[List[float]]): Node coordinates (as nested lists).
        id (bm.array | None): Node IDs as array.
        node (bm.array | None): Node coordinates as array.
        node_map (bm.array | None): Mapping from node ID to index in the node array.

    Methods:
        parse_line(line: str): Parses a single line of node data.
        finalize(): Converts internal storage to bm.array and builds index mapping.
        attach(meshdata: Dict[str, Any]): Adds node map to shared meshdata dictionary.
    """
    keyword = 'NODE'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self._id: List[int] = []
        self._node: List[List[float]] = []
        self.id: Optional[Any] = None
        self.node: Optional[Any] = None

    def parse_line(self, line: str) -> None:
        parts = [s.strip() for s in line.split(',')]
        nid = int(parts[0])
        coords = [float(val) for val in parts[1:]]
        self._id.append(nid)
        self._node.append(coords)

    def finalize(self) -> None:
        dim = max(len(coords) for coords in self._node)
        for coords in self._node:
            if len(coords) < dim:
                coords.extend([0.0] * (dim - len(coords)))
        self.id = bm.array(self._id)
        self.node = bm.array(self._node)

    def attach(self, meshdata: Dict[str, Any]) -> None:
        meshdata.add_node_data("id", self.id)

class ElementSection(Section):
    """
    Parses the *ELEMENT section from an ABAQUS .inp file.

    This section defines element connectivity using global node IDs. It stores both raw
    data and post-processed tensor structures for efficient access.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header.

    Attributes:
        _id (List[int]): Element IDs parsed from each line.
        _cell (List[List[int]]): Element connectivity, where each list contains the node IDs of an element.
        id (bm.array | None): Array of element IDs.
        cell (bm.array | None): Array of element connectivities.
        cell_map (bm.array | None): Index mapping from element ID to row index in the `cell` array.

    Methods:
        parse_line(line: str): Parses a single line of element connectivity data.
        finalize(): Converts internal storage to bm.array and builds element ID index mapping.
        attach(meshdata: Dict[str, Any]): Adds element map to shared meshdata dictionary.
    """
    keyword = 'ELEMENT'

    ELEMENT_TYPE_MAP = {
        'C3D4': 4,  # 4-node linear tetrahedral element (1st-order)
        'C3D10': 10,  # 10-node quadratic tetrahedral element (2nd-order)
        'C3D8': 8,  # 8-node linear hexahedral element (1st-order)
        'C3D20': 20,  # 20-node quadratic hexahedral element (2nd-order)
        # Additional element types can be added here
    }

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self._id: List[int] = []
        self._cell: List[List[int]] = []
        self._line_buffer: str = ""
        self.multi_line = False

        # final arrays
        self.id: Optional[Any] = None
        self.cell: Optional[Any] = None
        
        self.element_type = self.options.get('TYPE', 'C3D4').upper()

    def parse_line(self, line: str) -> None:
        line = line.strip()

        if line.endswith(','):
            self._line_buffer += line[:-1].strip()
            self.multi_line = True
        else:
            if self.multi_line:  
                self._line_buffer += ',' + line.strip()
            else:
                self._line_buffer += line.strip()

            parts = [s.strip() for s in self._line_buffer.split(',')]
            eid = int(parts[0])
            
            conn = [int(val) for val in parts[1:]]
            
            expected_nodes = self.ELEMENT_TYPE_MAP.get(self.element_type, None)
            if expected_nodes is None:
                raise ValueError(f"Unknown element type: {self.element_type}")

            if len(conn) != expected_nodes:
                
                raise ValueError(f"Element {eid} has {len(conn)} nodes, expected {expected_nodes} nodes.")

            self._id.append(eid)
            self._cell.append(conn)

            self._line_buffer = ""

    def finalize(self) -> None:
        if self.element_type == 'C3D4':
            vertex_conn = bm.array(self._cell)
        if self.element_type == 'C3D10':
            vertex_conn = bm.array(self._cell)[:,:4]

        self.id = bm.array(self._id)
        self.cell = vertex_conn

    def attach(self, meshdata: Dict[str, Any]) -> None:
        meshdata.add_cell_data("id", self.id)


class ElsetSection(Section):
    """
    Parses the *ELSET section from an ABAQUS .inp file.

    This section defines a named set of elements, which can be specified directly or generated via a range.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header, including 'elset' name and 'generate' flag.

    Attributes:
        name (str): Name of the element set.
        generate (bool): Whether the element IDs should be generated from a range.
        _id (List[int]): List of element IDs in the set.
        id (bm.array | None): Final array of element IDs.

    Methods:
        parse_line(line: str): Parses a line of element IDs or a generation command.
        finalize(): Converts internal storage to bm.array.
        attach(meshdata: Dict[str, Any]): Adds named element set to meshdata using 'cell_map'.
    """
    keyword = 'ELSET'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.name = options.get('elset', '')
        self.generate = options.get('generate', '').lower() == 'true'
        self._id: List[int] = []
        self.id: Optional[Any] = None

    def parse_line(self, line: str) -> None:
        parts = re.split(r'\s*,\s*', line)
        if self.generate:
            start, stop, step = map(int, parts[:3])
            self._id.extend(range(start, stop + 1, step))
        else:
            for p in parts:
                if p:
                    self._id.append(int(p))

    def finalize(self) -> None:
        self.id = bm.array(self._id)

    def attach(self, meshdata: Dict[str, Any]):
        meshdata.add_cell_set(self.name, self.id)

class NsetSection(Section):
    """
    Parses the *NSET section from an ABAQUS .inp file.

    This section defines a named set of nodes, which are usually used to
    apply boundary conditions, loads, or group nodes for referencing in
    later sections such as materials or couplings.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header,
            including the 'nset' name.

    Attributes:
        name (str): Name of the node set.
        _id (List[int]): List of node IDs.
        id (bm.array | None): Final array of node indices.

    Methods:
        parse_line(line: str): Parses comma-separated node IDs from each line.
        finalize(): Converts node ID list to a tensor array.
        attach(meshdata: Dict[str, Any]): Adds the named node set to meshdata using the node map.
    """
    keyword = 'NSET'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.name = options.get('nset', '')
        self._id: List[int] = []
        self.id: Optional[Any] = None

    def parse_line(self, line: str) -> None:
        parts = re.split(r'\s*,\s*', line)
        for p in parts:
            if p:
                self._id.append(int(p))

    def finalize(self) -> None:
        self.id = bm.array(self._id)

    def attach(self, meshdata: Dict[str, Any]):
        meshdata.add_node_set(self.name, self.id)


class SolidSection(Section):
    """
    Parses the *SOLID SECTION from an ABAQUS .inp file.

    This section maps a named element set to a specific material name. It
    typically contains no data lines but defines semantic groupings used
    for assigning materials in the mesh.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header,
            including 'elset' and 'material'.

    Attributes:
        elset (str): The name of the element set to which this solid section applies.
        material (str): The name of the material assigned to the element set.

    Methods:
        parse_line(line: str): No-op. Solid section information is header-only.
        attach(meshdata: Dict[str, Any]): Records the material-to-elset mapping in the meshdata dictionary.
    """
    keyword = 'SOLID SECTION'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.elset: Optional[str] = options.get('elset', '')
        self.material: Optional[str] = options.get('material', '')

    def parse_line(self, line: str) -> None:
        # Usually no data to parse; solid section info is in the header
        pass

    def attach(self, meshdata: Dict[str, Any]) -> None:
        meshdata.add_physics_resions(
                self.elset+self.material, 
                self.elset,
                self.material
                )


class SystemSection(Section):
    """
    Parses the *SYSTEM section from an ABAQUS .inp file.

    This section allows for storage of arbitrary system-level metadata or user-defined
    configuration content. It typically consists of plain text lines.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header.

    Attributes:
        data (List[str]): Raw lines of text data contained in the section.

    Methods:
        parse_line(line: str): Stores each non-empty line into the `data` list.
        attach(meshdata: Dict[str, Any]): Optional; can be overridden for post-processing.
    """
    keyword = 'SYSTEM'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.data = []

    def parse_line(self, line: str) -> None:
        self.data.append(line.strip())

class SurfaceSection(Section):
    """
    Parses the *SURFACE section from an ABAQUS .inp file.

    This section defines named surfaces, typically used for applying surface loads
    or for coupling and contact definitions. Each surface is defined by a set name
    and an associated type.

    Parameters:
        options (Dict[str, str]): Keyword arguments from the header line, including 'name' and 'type'.

    Attributes:
        name (str): Name of the surface.
        type (str): Surface type (e.g., 'ELEMENT', 'NODE', etc.).
        assignments (List[Tuple[str, float]]): List of surface assignments as (elset name, surface ID).

    Methods:
        parse_line(line: str): Parses each assignment line into (elset, surface ID).
        attach(meshdata: Dict[str, Any]): Adds the surface definition to meshdata.
    """
    keyword = 'SURFACE'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.name = options.get('name', '')
        self.type = options.get('type', '')
        self.data: List[Tuple[str, str]] = []

    def parse_line(self, line: str) -> None:
        parts = re.split(r'\s*,\s*', line.strip())
        if len(parts) >= 2:
            self.data.append((parts[0], parts[1]))

    def attach(self, meshdata: Dict[str, Any]) -> None:
        meshdata.add_surface(
                self.name,
                self.type,
                self.data
                )

class CouplingSection(Section):
    """
    Parses the *COUPLING section from an ABAQUS .inp file.

    This section defines coupling constraints that relate a reference node to a surface.
    Additional lines such as *KINEMATIC or *DISTRIBUTING indicate the specific type of coupling.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header,
            including constraint name, reference node, and surface.

    Attributes:
        name (str): Name of the coupling constraint.
        ref_node (str): Reference node identifier.
        surface (str): Name of the coupled surface.
        type (str | None): Coupling type (e.g., 'KINEMATIC', 'DISTRIBUTING'), to be set externally.

    Methods:
        parse_line(line: str): No-op. All data is extracted from the header.
        set_type(coupling_type: str): Sets the type of coupling constraint.
        attach(meshdata: Dict[str, Any]): Adds coupling info to the meshdata dictionary.
    """
    keyword = 'COUPLING'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.name = options.get('constraint name', '')
        self.ref_node = options.get('ref node', '')
        self.surface = options.get('surface', '')
        self.type = None  # To be set by subsequent *KINEMATIC or *DISTRIBUTING

    def parse_line(self, line: str) -> None:
        pass  # No data expected; coupling info is in header

    def set_type(self, coupling_type: str) -> None:
        self.type = coupling_type

    def attach(self, meshdata: Dict[str, Any]):
        meshdata.add_coupling(self.name, 
                              self.surface, 
                              self.ref_node,
                              self.type)


class MaterialSection(Section):
    """
    Parses the *MATERIAL section from an ABAQUS .inp file.

    This section collects material properties such as density and elasticity, typically
    defined in sub-keyword lines like *DENSITY and *ELASTIC.

    Parameters:
        options (Dict[str, str]): Keyword arguments extracted from the section header,
            including the material name.

    Attributes:
        name (str): Name of the material.
        density (float | None): Material density.
        elastic (Tuple[float, float] | None): Young's modulus and Poisson's ratio.
        _next (str | None): Internal flag to indicate which property is expected next.

    Methods:
        parse_line(line: str): Handles parsing of property declarations and values.
        attach(meshdata: Dict[str, Any]): Adds the material data to meshdata under its name.
    """
    keyword = 'MATERIAL'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.name = options.get('name', '')
        self.density: Optional[float] = None
        self.elastic: Optional[Tuple[float, float]] = None
        self._next = None  # internal flag for line parsing

    def parse_line(self, line: str) -> None:
        if self._next == 'DENSITY':
            self.density = float(line.strip().split(',')[0])
            self._next = None
        elif self._next == 'ELASTIC':
            parts = [float(x) for x in line.strip().split(',') if x]
            if len(parts) >= 2:
                self.elastic = (parts[0], parts[1])
            self._next = None
        else:
            if line.upper().startswith("*DENSITY"):
                self._next = 'DENSITY'
            elif line.upper().startswith("*ELASTIC"):
                self._next = 'ELASTIC'

    def attach(self, meshdata: Dict[str, Any]):
        meshdata.add_material(self.name, 
                              elastic_modulus=self.elastic[0],
                              poisson_ratio=self.elastic[1],
                              density=self.density)

class BoundarySection(Section):
    """
    Parses the *BOUNDARY section from an ABAQUS .inp file.

    This section defines constraints on node degrees of freedom (DOFs), typically
    used for boundary conditions.

    Parameters:

    Attributes:

    Methods:

    """

    keyword = 'BOUNDARY'

    def __init__(self, options: Dict[str, str]):
        super().__init__(options)
        self.options = options
        self.type = options.get('type','DISPLACEMENT').upper()
        self.data = []

    def parse_line(self, line: str) -> None:
        """
        Parses a line defining boundary conditions.
        """
        # Skip empty lines or comments
        if not line.strip() or line.strip().startswith('**'):
            return
        parts = [p.strip() for p in line.strip().split(',') if p.strip() != ""]
        nset = parts[0]
        dof_start = int(parts[1]) - 1
        dof_end = float(parts[2]) 
        if dof_end == 0.0:
            dof_end = dof_start + 1
            magnitude = 0.0
        else:
            dof_end = int(dof_end)
            magnitude = float(parts[3]) if len(parts) > 3 else 0.0
        self.data.append((nset, dof_start, dof_end, magnitude))

    def attach(self, meshdata: Dict[str, Any]):
        """
        Attach boundary conditions to meshdata under the 'boundary_conditions' key.
        Each condition is a dict containing region, type, dofs, magnitude, options, etc.
        """
        for bc in self.data:
            meshdata.add_boundary_condition(bc)


# Registry of available section handlers
SECTION_REGISTRY: List[Type[Section]] = [NodeSection, ElementSection, ElsetSection, 
                                         NsetSection, SolidSection, SystemSection,
                                         SurfaceSection, CouplingSection, MaterialSection,
                                         BoundarySection]
